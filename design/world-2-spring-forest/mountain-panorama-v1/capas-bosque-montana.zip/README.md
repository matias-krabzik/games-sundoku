# Capas del bosque hasta la montaña

Generadas con image_gen integrado; prompts completos en prompts.md. Original aprobado en master.png.

Orden: sky, clouds, mountains, distance, terrain, foreground.

Sky contiene cielo azul sin nubes. Mountains contiene solo cordillera lejana. Terrain conserva árboles próximos, camino, puente, cauce completo y montaña de llegada unidos; se completó por abajo para cubrir el movimiento del primer plano. Foreground contiene vegetación y rocas decorativas próximas.

Son intermedios opacos sobre gris, no exportaciones transparentes finales. No se sustituyeron los assets del juego. Antes de integrar: retirar gris preservando piedras y flores, igualar lienzos de 2171 a 2172 px añadiendo margen sin estirar, revisar bordes y composición en movimiento. No tienen overscan lateral adicional.

El panorama aprobado sigue siendo 3:1. Para duplicar físicamente la longitud habrá que generar tramos adicionales; no estirar este arte.

Dimensiones verificadas:

- clouds.png: 2172 × 724, RGB.
- distance.png: 2172 × 724, RGB.
- foreground.png: 2172 × 724, RGB.
- mountains.png: 2172 × 724, RGB.
- sky.png: 2171 × 724, RGB.
- terrain.png: 2171 × 724, RGB.
